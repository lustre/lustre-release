/******************************************************************************\
*                                                                              *
*        Copyright (c) 2003, The Regents of the University of California       *
*      See the file COPYRIGHT for a complete copyright notice and license.     *
*                                                                              *
********************************************************************************
*
* CVS info:
*   $RCSfile: aiori.h,v $
*   $Revision: 1.81 $
*   $Date: 2005/05/31 23:59:36 $
*   $Author: loewe $
*
* Purpose:
*       This is a header file that contains the definitions and prototypes
*       needed for the abstract I/O interfaces necessary for IOR.
*
\******************************************************************************/

#ifndef _AIORI_H
#define _AIORI_H

#include "iordef.h"                                     /* IOR Definitions */
#include <mpi.h>

#ifndef MPI_FILE_NULL
#   include <mpio.h>
#endif /* not MPI_FILE_NULL */

#include <sys/param.h>                                  /* MAXPATHLEN */
#include <string.h>

/*************************** D E F I N I T I O N S ****************************/

                                /* -- file open flags -- */
#define IOR_RDONLY        1     /* read only */
#define IOR_WRONLY        2     /* write only */
#define IOR_RDWR          4     /* read/write */
#define IOR_APPEND        8     /* append */
#define IOR_CREAT         16    /* create */
#define IOR_TRUNC         32    /* truncate */
#define IOR_EXCL          64    /* exclusive */
#define IOR_DIRECT        128   /* bypass I/O buffers */
                                /* -- file mode flags -- */
#define IOR_IRWXU         1     /* read, write, execute perm: owner */
#define IOR_IRUSR         2     /* read permission: owner */
#define IOR_IWUSR         4     /* write permission: owner */
#define IOR_IXUSR         8     /* execute permission: owner */
#define IOR_IRWXG         16    /* read, write, execute perm: group */
#define IOR_IRGRP         32    /* read permission: group */
#define IOR_IWGRP         64    /* write permission: group */
#define IOR_IXGRP         128   /* execute permission: group */
#define IOR_IRWXO         256   /* read, write, execute perm: other */
#define IOR_IROTH         512   /* read permission: other */
#define IOR_IWOTH         1024  /* write permission: other */
#define IOR_IXOTH         2048  /* execute permission: other */

/******************************************************************************/
/*
 * The parameter struct holds all of the "global" data to be passed,
 * as well as results to be parsed.
 *
 * NOTE: If this is changed, also change:
 *         defaultParameters [defaults.h]
 *         DisplayUsage() [IOR.c]
 *         ShowTest() [IOR.c]
 *         DecodeDirective() [parse_options.c]
 *         ParseCommandLine() [parse_options.c]
 *         README
 *         IOR-GUI.py
 */

typedef struct
{
    char debug[MAX_STR];             /* debug info string */
    unsigned int mode;               /* file permissions */
    unsigned int openFlags;          /* open flags */
    char api[MAX_STR];               /* API for I/O */
    char apiVersion[MAX_STR];        /* API version */
    char platform[MAX_STR];          /* platform type */
    char testFileName[MAXPATHLEN];   /* full name for test */
    char hintsFileName[MAXPATHLEN];  /* full name for hints file */
    char options[MAXPATHLEN];        /* options string */
    int numTasks;                    /* number of tasks for test */
    int nodes;                       /* number of nodes for test */
    int tasksPerNode;                /* number of tasks per node */
    int repetitions;                 /* number of repetitions of test */
    int repCounter;                  /* rep counter */
    int multiFile;                   /* multiple files */
    int interTestDelay;              /* delay between reps in seconds */
    double * writeVal;               /* array to write results */
    double * readVal;                /* array to read results */
    int open;                        /* flag for writing or reading */
    int readFile;                    /* read of existing file */
    int writeFile;                   /* write of file */
    int filePerProc;                 /* single file or file-per-process */
    int reorderTasks;                /* reorder tasks for read back and check */
    int checkWrite;                  /* check read after write */
    int checkRead;                   /* check read after read */
    int keepFile;                    /* don't delete the testfile on exit */
    int quitOnError;                 /* quit code when error in check */
    int collective;                  /* collective I/O */
    IOR_offset_t segmentCount;       /* number of segments (or HDF5 datasets) */
    IOR_offset_t blockSize;          /* contiguous bytes to write per task */
    IOR_offset_t transferSize;       /* size of transfer in bytes */
    IOR_offset_t offset;             /* offset for read/write */
    IOR_offset_t actualFileSize;     /* actual aggregate file size */
    IOR_offset_t expectedFileSize;   /* expected aggregate file size */
    int preallocate;                 /* preallocate file size */
    int useFileView;                 /* use MPI_File_set_view */
    int useSharedFilePointer;        /* use shared file pointer */
    int useStridedDatatype;          /* put strided access into datatype */
    int useO_DIRECT;                 /* use O_DIRECT, bypassing I/O buffers */
    int showHints;                   /* show hints */
    int showHelp;                    /* show options and help */
    int uniqueDir;                   /* use unique directory for each fpp */
    int useExistingTestFile;         /* do not delete test file before access */
    int storeFileOffset;             /* use file offset as stored signature */
    int maxTimeDuration;             /* max time in minutes to run tests */
    int verbose;                     /* verbosity */

    /* POSIX variables */
    int singleXferAttempt;           /* do not retry transfer if incomplete */
    int fsync;                       /* fsync() after write */

    /* MPI variables */
    MPI_Datatype transferType;       /* datatype for transfer */
    MPI_Datatype fileType;           /* filetype for file view */

    /* HDF5 variables */
    int individualDataSets;          /* datasets not shared by all procs */
    int noFill;                      /* no fill in file creation */

    /* NCMPI variables */
    int var_id;                      /* variable id handle for data set */

    /* Lustre variables */
    int lustre_stripe_count;
    int lustre_stripe_size;
    int lustre_start_ost;
    int lustre_ignore_locks;

    int id;                          /* test's unique ID */
    int intraTestBarriers;           /* barriers between open/op and op/close */
} IOR_param_t;


/**************************** P R O T O T Y P E S *****************************/

/* functions for aiori-*.c */
/* POSIX-specific functions */
void *       IOR_Create_POSIX    (char *, IOR_param_t *);
void *       IOR_Open_POSIX      (char *, IOR_param_t *);
IOR_offset_t IOR_Xfer_POSIX      (int, void *, IOR_size_t *,
                                  IOR_offset_t, IOR_param_t *);
void         IOR_Close_POSIX     (void *, IOR_param_t *);
void         IOR_Delete_POSIX    (char *);
void         IOR_SetVersion_POSIX(IOR_param_t *);
void         IOR_Fsync_POSIX     (void *);

/* MPIIO-specific functions */
void *       IOR_Create_MPIIO    (char *, IOR_param_t *);
void *       IOR_Open_MPIIO      (char *, IOR_param_t *);
IOR_offset_t IOR_Xfer_MPIIO      (int, void *, IOR_size_t *,
                                  IOR_offset_t, IOR_param_t *);
void         IOR_Close_MPIIO     (void *, IOR_param_t *);
void         IOR_Delete_MPIIO    (char *);
void         IOR_SetVersion_MPIIO(IOR_param_t *);
void         IOR_Fsync_MPIIO     (void *);

/* HDF5-specific functions */
void *       IOR_Create_HDF5    (char *, IOR_param_t *);
void *       IOR_Open_HDF5      (char *, IOR_param_t *);
IOR_offset_t IOR_Xfer_HDF5      (int, void *, IOR_size_t *,
                                 IOR_offset_t, IOR_param_t *);
void         IOR_Close_HDF5     (void *, IOR_param_t *);
void         IOR_Delete_HDF5    (char *);
void         IOR_SetVersion_HDF5(IOR_param_t *);
void         IOR_Fsync_HDF5     (void *);

/* NCMPI-specific functions */
void *       IOR_Create_NCMPI    (char *, IOR_param_t *);
void *       IOR_Open_NCMPI      (char *, IOR_param_t *);
IOR_offset_t IOR_Xfer_NCMPI      (int, void *, IOR_size_t *,
                                  IOR_offset_t, IOR_param_t *);
void         IOR_Close_NCMPI     (void *, IOR_param_t *);
void         IOR_Delete_NCMPI    (char *);
void         IOR_SetVersion_NCMPI(IOR_param_t *);
void         IOR_Fsync_NCMPI     (void *);

#endif /* not _AIORI_H */
