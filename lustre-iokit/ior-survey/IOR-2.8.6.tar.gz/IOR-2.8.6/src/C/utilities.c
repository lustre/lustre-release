/******************************************************************************\
*                                                                              *
*        Copyright (c) 2003, The Regents of the University of California       *
*      See the file COPYRIGHT for a complete copyright notice and license.     *
*                                                                              *
********************************************************************************
*
* CVS info:
*   $RCSfile: utilities.c,v $
*   $Revision: 1.17 $
*   $Date: 2004/05/13 00:28:54 $
*   $Author: loewe $
*
* Purpose:
*       Additional utilities necessary for both MPIIO and HDF5.
*
\******************************************************************************/

#include "aiori.h"                                  /* abstract IOR interface */
#include "IOR.h"                                    /* IOR functions */
#include <errno.h>                                  /* sys_errlist */
#include <fcntl.h>                                  /* open() */
#include <stdio.h>                                  /* only for fprintf() */
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>


/************************** D E C L A R A T I O N S ***************************/

extern int      errno,                                /* error number */
                numTasks,                             /* MPI variables */
                rank,
                rankOffset,
                verbose;                              /* verbose output */


/***************************** F U N C T I O N S ******************************/

/******************************************************************************/
/*
 * Compares hostnames to determine the number of tasks per node
 */

void
CorruptTheFile(char         * fileName,
               IOR_offset_t   offset,
               int            byteValue)
{
    int       fd;
    char      oldValue[1],
              value[1];

    value[0] = (char)byteValue;

    /* open file, show old value, update to new value */
    fd = open(fileName, O_RDWR);
    lseek(fd, offset, SEEK_SET);
    read(fd, oldValue, 1);
    fprintf(stdout,
            "** DEBUG: offset %lld in %s changed from %d to %d **\n",
            offset, fileName, (int)oldValue[0], (int)value[0]);
    lseek(fd, offset, SEEK_SET);
    write(fd, value, 1);
    close(fd);

    return;
} /* CorruptTheFile() */


/******************************************************************************/
/*
 * Set hints for MPIIO or HDF5.
 */

void
SetHints(MPI_Info * mpiHints, char * hintsFileName)
{
    char           hintString[MAX_STR],
                   settingVal[MAX_STR],
                   valueVal[MAX_STR];
    extern char ** environ;
    int            i;
    FILE         * fd;

    /*
     * This routine checks for hints from the environment and/or from the
     * hints files.  The hints are of the form:
     * 'IOR_HINT__<layer>__<hint>=<value>', where <layer> is either 'MPI'
     * or 'GPFS', <hint> is the full name of the hint to be set, and <value>
     * is the hint value.  E.g., 'setenv IOR_HINT__MPI__IBM_largeblock_io true'
     * or 'IOR_HINT__GPFS__hint=value' in the hints file.
     */
    MPI_CHECK(MPI_Info_create(mpiHints), "cannot create info object");

    /* get hints from environment */
    for (i = 0; environ[i] != NULL; i++) {
        /* if this is an IOR_HINT, pass the hint to the info object */
        if (strncmp(environ[i], "IOR_HINT", strlen("IOR_HINT")) == 0) {
            strcpy(hintString, environ[i]);
	    ExtractHint(settingVal, valueVal, hintString);
            MPI_CHECK(MPI_Info_set(*mpiHints, settingVal, valueVal),
                      "cannot set info object");
        }
    }

    /* get hints from hints file */
    if (strcmp(hintsFileName, "") != 0) {

        /* open the hint file */
        fd = fopen(hintsFileName, "r");
        if (fd == NULL)
            ERR("cannot open file");

        /* iterate over hints file */
        while(fgets(hintString, MAX_STR, fd) != NULL) {
            if (strncmp(hintString, "IOR_HINT", strlen("IOR_HINT")) == 0) {
                ExtractHint(settingVal, valueVal, hintString);
                MPI_CHECK(MPI_Info_set(*mpiHints, settingVal, valueVal),
                          "cannot set info object");
	    }
	}

        /* close the script */
        if (fclose(fd) != 0) ERR("cannot close script file");
    }
} /* SetHints() */


/******************************************************************************/
/*
 * Extract key/value pair from hint string.
 */

void
ExtractHint(char * settingVal,
            char * valueVal,
            char * hintString)
{
    char * settingPtr,
         * valuePtr,
         * tmpPtr1,
         * tmpPtr2;

    settingPtr = (char *)strtok(hintString, "=");
    valuePtr = (char *)strtok(NULL, "");
    tmpPtr1 = settingPtr;
    tmpPtr2 = (char *)strstr(settingPtr, "IOR_HINT__MPI__");
    if (tmpPtr1 == tmpPtr2) {
        settingPtr += strlen("IOR_HINT__MPI__");

    } else {
        tmpPtr2 = (char *)strstr(settingPtr, "IOR_HINT__GPFS__");
        if (tmpPtr1 == tmpPtr2) {
            settingPtr += strlen("IOR_HINT__GPFS__");
            fprintf(stdout,
	            "WARNING: Unable to set GPFS hints (not implemented.)\n");
        }
    }
    strcpy(settingVal, settingPtr);
    strcpy(valueVal, valuePtr);
} /* ExtractHint() */


/******************************************************************************/
/*
 * Show all hints (key/value pairs) in an MPI_Info object.
 */

void ShowHints(MPI_Info * mpiHints)
{
    char key[MPI_MAX_INFO_VAL],
         value[MPI_MAX_INFO_VAL];
    int  flag,
         i,
         nkeys;

    MPI_CHECK(MPI_Info_get_nkeys(*mpiHints, &nkeys),
              "cannot get info object keys");

    for (i = 0; i < nkeys; i++) {
        MPI_CHECK(MPI_Info_get_nthkey(*mpiHints, i, key),
                  "cannot get info object key");
        MPI_CHECK(MPI_Info_get(*mpiHints, key, MPI_MAX_INFO_VAL-1,
                               value, &flag),
                  "cannot get info object value");
        fprintf(stdout,"\t%s = %s\n", key, value);
    }
} /* ShowHints() */
