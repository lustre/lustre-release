/******************************************************************************\
*                                                                              *
*        Copyright (c) 2003, The Regents of the University of California       *
*      See the file COPYRIGHT for a complete copyright notice and license.     *
*                                                                              *
********************************************************************************
*
* CVS info:
*   $RCSfile: IOR.h,v $
*   $Revision: 1.39 $
*   $Date: 2004/07/28 16:03:42 $
*   $Author: loewe $
*
* Purpose:
*       This is a header file that contains the definitions and prototypes
*       needed for IOR.c.
*
\******************************************************************************/

#ifndef _IOR_H
#define _IOR_H

#include "aiori.h"                                 /* abstract IOR interfaces */
#include "iordef.h"                                /* IOR Definitions */


/*************************** D E F I N I T I O N S ****************************/

/* define the queuing structure for the test parameters */
typedef struct IOR_queue_t {
    IOR_param_t testParameters;
    struct IOR_queue_t * nextTest;
} IOR_queue_t;


/**************************** P R O T O T Y P E S *****************************/

/* functions used in IOR.c */
void           AioriBind        (char *);
char *         CheckTorF        (char *);
unsigned long  CompareBuffers   (void *, void *, unsigned long,
                                 IOR_offset_t, IOR_param_t *, const char *);
int            CountTasksPerNode(void);
void *         CreateBuffer     (unsigned long);
IOR_queue_t *  CreateNewTest    (int);
void           DelaySecs        (int);
void           DisplayFreespace (int, char **);
void           DisplayUsage     (char **);
void           DistributeHints  (void);
void           FreeBuffer       (void *);
void           FillBuffer       (void *, unsigned long,
                                 unsigned long long, int);
void           GetPlatformName  (char *);
void           GetTestFileName  (char *, IOR_param_t *);
double         GetTimeStamp     (void);
char *         HumanReadable    (IOR_offset_t, int);
char *         LowerCase        (char *);
void           PPDouble         (int, double, char *);
char *         PrependDir       (char *);
IOR_queue_t *  ParseCommandLine (int, char **);
char **        ParseFileName    (char *, int *);
void           ReduceIterResults(IOR_param_t *, double **, int, int);
void           RemoveFile       (char *, int);
IOR_queue_t *  SetupTests       (int, char **);
void           ShowInfo         (int, char **);
void           ShowSetup        (IOR_param_t *);
void           ShowTest         (IOR_param_t *);
IOR_offset_t   StringToBytes    (char *);
void           SummarizeResults (IOR_param_t *);
void           TestIoSys        (IOR_param_t *);
double         TimeDeviation    (void);
void           ValidTests       (IOR_param_t *);
void           WriteOrRead      (IOR_param_t *, void *, int);
void           WriteTimes       (IOR_param_t *, double **, int, int);

/* functions used in utilities.c */
void           CorruptTheFile   (char *, IOR_offset_t, int);
void           ExtractHint      (char *, char *, char *);
void           SetHints         (MPI_Info *, char *);
void           ShowHints        (MPI_Info *);

#endif /* not _IOR_H */
