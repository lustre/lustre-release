/******************************************************************************\
*                                                                              *
*        Copyright (c) 2003, The Regents of the University of California       *
*      See the file COPYRIGHT for a complete copyright notice and license.     *
*                                                                              *
********************************************************************************
*
* CVS info:
*   $RCSfile: IOR.c,v $
*   $Revision: 1.146 $
*   $Date: 2005/06/29 15:42:18 $
*   $Author: loewe $
*
* Purpose:
*       Test file system I/O.
*
* Settings and Usage:
*       View DisplayUsage() for settings.
*       Usage is with either the IOR-GUI.py script, or with an input script
*       file of the form shown in DisplayUsage().
*
* History (see CVS log for detailed history):
*       2001.11.21  wel
*                   Started initial implementation of code.
*       2002.02.07  wel
*                   Added abstract IOR interface for I/O.
*       2002.03.29  wel
*                   Added MPI synchronization.
*       2002.04.15  wel
*                   Added MPIIO.
*       2002.08.07  wel
*                   Added MPI file hints, collective calls, file views, etc.
*       2002.11.06  wel
*                   Added HDF5.
*       2003.10.03  wel
*                   Added NCMPI.
*
* Known problems and limitations:
*       DisplaySecs() may be necessary for file system stability during
*       testing, though this is still under consideration.
*
\******************************************************************************/

#include "aiori.h"                                    /* IOR I/O interfaces */
#include "IOR.h"                                      /* IOR definitions
                                                         and prototypes */
#include "IOR-aiori.h"                                /* IOR abstract
                                                         interfaces */
#include <ctype.h>                                    /* tolower() */
#include <errno.h>                                    /* sys_errlist */
#include <math.h>
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/param.h>                                /* MAXPATHLEN */
#include <sys/stat.h>                                 /* struct stat */
#include <sys/time.h>                                 /* gettimeofday() */
#include <sys/utsname.h>                              /* uname() */
#include <time.h>
#include <unistd.h>

/************************** D E C L A R A T I O N S ***************************/

extern IOR_param_t defaultParameters;
extern int     errno;                                   /* error number */
extern char ** environ;
int            numTasksWorld         = 0;
int            rank                  = 0;
int            rankOffset            = 0;
int            tasksPerNode          = 0;               /* tasks per node */
int            verbose               = NO_VERBOSE;      /* verbose output */
double         wall_clock_deviation;
MPI_Comm       testComm;

/********************************** M A I N ***********************************/

int
main(int     argc,
     char ** argv)
{
    int           i;
    IOR_queue_t * tests;

    /*
     * check -h option from commandline without starting MPI;
     * if the help option is requested in a script file (showHelp=TRUE),
     * the help output will be displayed in the MPI job
     */
    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-h") == 0) {
	    DisplayUsage(argv);
	    return 2;
        }
    }

    /* start the MPI code */
    MPI_CHECK(MPI_Init(&argc, &argv), "cannot initialize MPI");
    MPI_CHECK(MPI_Comm_size(MPI_COMM_WORLD, &numTasksWorld),
	      "cannot get number of tasks");
    MPI_CHECK(MPI_Comm_rank(MPI_COMM_WORLD, &rank), "cannot get rank");
    /* set error-handling */
    /*MPI_CHECK(MPI_Errhandler_set(MPI_COMM_WORLD, MPI_ERRORS_RETURN),
      "cannot set errhandler");*/
    
    /* setup tests before verifying test validity */
    tests = SetupTests(argc, argv);
    verbose = tests->testParameters.verbose;
    
    /* check for commandline usage */
    if (rank == 0 && tests->testParameters.showHelp == TRUE) {
      DisplayUsage(argv);
    }
    
    /* perform each test */
    while (tests != NULL) {
      verbose = tests->testParameters.verbose;
      if (rank == 0) ShowInfo(argc, argv);
      if (rank == 0 && verbose >= HIGH_VERBOSE)
	ShowTest(&tests->testParameters);
      TestIoSys(&tests->testParameters);
      tests = tests->nextTest;
    }

    /* display finish time */
    if (rank == 0) {
      time_t   currentTime;
      char   * currentTimePtr;

      if ((currentTime = time(NULL)) == -1)
	ERR("cannot get current time");
      if ((currentTimePtr = ctime(&currentTime)) == NULL)
	ERR("cannot read current time");
      /* ctime string ends in \n */
      fprintf(stdout, "Run finished: %s", currentTimePtr);
    }
	
    MPI_CHECK(MPI_Finalize(), "cannot finalize MPI");

    return(0);

} /* main() */


/***************************** F U N C T I O N S ******************************/

/******************************************************************************/
/*
 * Bind abstract I/O function pointers to API-specific functions.
 */

void
AioriBind(char * api)
{
    if (strcmp(api, "POSIX") == 0) {
        IOR_Create     = IOR_Create_POSIX;
        IOR_Open       = IOR_Open_POSIX;
        IOR_Xfer       = IOR_Xfer_POSIX;
        IOR_Close      = IOR_Close_POSIX;
        IOR_Delete     = IOR_Delete_POSIX;
	IOR_SetVersion = IOR_SetVersion_POSIX;
	IOR_Fsync      = IOR_Fsync_POSIX;
    } else if (strcmp(api, "MPIIO") == 0) {
        IOR_Create     = IOR_Create_MPIIO;
        IOR_Open       = IOR_Open_MPIIO;
        IOR_Xfer       = IOR_Xfer_MPIIO;
        IOR_Close      = IOR_Close_MPIIO;
        IOR_Delete     = IOR_Delete_MPIIO;
	IOR_SetVersion = IOR_SetVersion_MPIIO;
	IOR_Fsync      = IOR_Fsync_MPIIO;
    } else if (strcmp(api, "HDF5") == 0) {
        IOR_Create     = IOR_Create_HDF5;
        IOR_Open       = IOR_Open_HDF5;
        IOR_Xfer       = IOR_Xfer_HDF5;
        IOR_Close      = IOR_Close_HDF5;
        IOR_Delete     = IOR_Delete_HDF5;
	IOR_SetVersion = IOR_SetVersion_HDF5;
	IOR_Fsync      = IOR_Fsync_HDF5;
    } else if (strcmp(api, "NCMPI") == 0) {
        IOR_Create     = IOR_Create_NCMPI;
        IOR_Open       = IOR_Open_NCMPI;
        IOR_Xfer       = IOR_Xfer_NCMPI;
        IOR_Close      = IOR_Close_NCMPI;
        IOR_Delete     = IOR_Delete_NCMPI;
        IOR_SetVersion = IOR_SetVersion_NCMPI;
	IOR_Fsync      = IOR_Fsync_NCMPI;
    } else {
        ERR("Unrecognized IO API");
    }
} /* AioriBind() */


/******************************************************************************/
/*
 * Check if string is true or false.
 */

char *
CheckTorF(char * string)
{
    string = LowerCase(string);
    if (strcmp(string, "false") == 0) {
        strcpy(string, "0");
    } else if (strcmp(string, "true") == 0) {
        strcpy(string, "1");
    }
    return(string);
} /* CheckTorF() */


/******************************************************************************/
/*
 * Compare buffers after reading/writing each transfer.  Displays only first
 * difference in buffers and returns total errors counted.
 */

unsigned long
CompareBuffers(void          * expectedBuffer,
               void          * unknownBuffer,
               unsigned long   size,
               IOR_offset_t    transferCount,
               IOR_param_t   * test,
               const char    * access)
{
    unsigned long       i, j, length, first, last;
    unsigned long       errorCount  = 0;
    int                 inError = 0;
    unsigned long long *goodbuf = (unsigned long long *)expectedBuffer;
    unsigned long long *testbuf = (unsigned long long *)unknownBuffer;

    length = size / sizeof(IOR_size_t);
    first = -1;
    if (verbose >= HIGH_VERBOSE) {
        fprintf(stdout, "[%d] comparing size %lu offset %lld length %ld\n",
                rank, size, test->offset, length);
    }
    for (i = 0; i < length; i++) {
        if (testbuf[i] != goodbuf[i]) {
	    if (!inError) {
		inError = 1;
		first = i;
		last = i;
	    } else {
		last = i;
	    }
	} else if (verbose >= ALL_VERBOSE && i % 4 == 0) {
            fprintf(stdout, "[%d] PASSED offset = %lld bytes, transfer %ld\n",
		    rank, ((i * sizeof(unsigned long long)) + test->offset),
                    (long)transferCount);
            fprintf(stdout, "[%d] GOOD Expected:0x", rank);
	    for (j = 0; j < 4; j++)
		fprintf(stdout, "%016llx ", goodbuf[i + j]);
	    fprintf(stdout, "\n[%d] GOOD Actual  :0x", rank);
	    for (j = 0; j < 4; j++)
		fprintf(stdout, "%016llx ", testbuf[i + j]);
	    fprintf(stdout, "\n");
	}
    }
    if (inError) {
	inError = 0;
	fprintf(stdout,
		"[%d] FAILED buffer comparison for buffer indexes %ld to %ld\n",
		rank, first, last);
	fprintf(stdout, "[%d]   file offset = %lld bytes, transfer %ld\n",
		rank, ((first * sizeof(unsigned long long)) + test->offset),
		(long)transferCount);
	fprintf(stdout, "[%d] Expected:0x", rank);
	for (j = first; j <= last && j < first + 4; j++)
	    fprintf(stdout, "%016llx ", goodbuf[j]);
	fprintf(stdout, "\n[%d] Actual  :0x", rank);
	for (j = first; j <= last && j < first + 4; j++)
	    fprintf(stdout, "%016llx ", testbuf[j]);
	fprintf(stdout, "\n");
	if (test->quitOnError == TRUE)
	    ERR("data check error, aborting execution");
	errorCount += last - first + 1;
    }
    return(errorCount);
} /* CompareBuffers() */


/******************************************************************************/
/*
 * Compares hostnames to determine the number of tasks per node
 */

int
CountTasksPerNode(void)
{
    char       localhost[MAX_STR],
               hostname[MAX_STR];
    int        count               = 1,
               i;
    MPI_Status status;

    if (gethostname(localhost, MAX_STR) != 0) {
        if (rank == 0)
	    fprintf(stdout,
		"WARNING: gethostname() failed, assuming 1 task per node\n");
	sprintf(localhost, "%d", rank);
    }
    if (rank == 0) {
        /* MPI_receive all hostnames, and compare to local hostname */
        for (i = 0; i < numTasksWorld-1; i++) {
            MPI_CHECK(MPI_Recv(hostname, MAX_STR, MPI_CHAR, MPI_ANY_SOURCE,
                               MPI_ANY_TAG, MPI_COMM_WORLD, &status),
                      "cannot receive hostnames");
            if (strcmp(hostname, localhost) == 0)
                count++;
        }
    } else {
        /* MPI_send hostname to root node */
        MPI_CHECK(MPI_Send(localhost, MAX_STR, MPI_CHAR, 0, 0,
                           MPI_COMM_WORLD), "cannot send hostname");
    }
    MPI_CHECK(MPI_Bcast(&count, 1, MPI_INT, 0, MPI_COMM_WORLD),
	      "cannot broadcast tasks-per-node value");

    return(count);
} /* CountTasksPerNode() */


/******************************************************************************/
/*
 * Allocate a page-aligned (required by O_DIRECT) buffer.
 */

void *
CreateBuffer(unsigned long size)
{
    long  pageSize;
    long  pageMask;
    char *buf, *tmp;
    char *aligned;

    pageSize = getpagesize();
    pageMask = pageSize-1;
    buf = malloc(size + pageSize + sizeof(void *));
    if (buf == NULL)
	ERR("out of memory");
    /* find the alinged buffer */
    tmp = buf + sizeof(char *);
    aligned = tmp + pageSize - ((unsigned long)tmp & pageMask);
    /* write a pointer to the original malloc()ed buffer into the bytes
       preceding "aligned", so that the aligned buffer can later be free()ed */
    tmp = aligned - sizeof(void *);
    *(void **)tmp = buf;
    
    return((void *)aligned);
} /* CreateBuffer() */

void
FreeBuffer(void *buffer)
{
    free( *(void **)((char *)buffer - sizeof(char *)) );
}
 
/******************************************************************************/
/*
 * Create new test for list of tests.
 */

IOR_queue_t *
CreateNewTest(int test_num)
{
    IOR_queue_t * newTest         = NULL;

    newTest = (IOR_queue_t *)malloc(sizeof(IOR_queue_t));
    if (newTest == NULL) ERR("out of memory");
    newTest->testParameters = defaultParameters;
    GetPlatformName(newTest->testParameters.platform);
    newTest->testParameters.nodes = defaultParameters.numTasks / tasksPerNode;
    newTest->testParameters.tasksPerNode = tasksPerNode;
    newTest->testParameters.id = test_num;
    newTest->nextTest = NULL;
    return(newTest);
} /* CreateNewTest() */


/******************************************************************************/
/*
 * Sleep for 'delay' seconds.
 */

void
DelaySecs(int delay)
{
    if (rank == 0 && delay > 0) {
        fprintf(stdout, "delaying %d seconds . . .\n", delay);
        sleep(delay);
    }
} /* DelaySecs() */


/******************************************************************************/
/*
 * Display freespace (df).
 */
void
DisplayFreespace(int     argc,
                 char ** argv)
{
    char cmdString[MAX_STR];
    char fileName[MAX_STR] = {0};
    int i;

    for (i = 0; i < argc; i++) {
	if ((i > 0) && (strcmp(argv[i-1], "-o") == 0)) {
	    strcpy(fileName, argv[i]);
            break;
        }
    }

    if (strcmp(fileName, "") != 0) {
	i = strlen(fileName);
	while (i-- > 0) {
	    if (fileName[i] == '/') {
		fileName[i] = '\0';
		break;
	    }
	}
	sprintf(cmdString, "df %s", fileName);
        if (verbose >= LOW_VERBOSE) fprintf(stdout, "%s:\n", cmdString);
        system(cmdString);
    }
    return;
} /* DisplayFreespace() */


/******************************************************************************/
/*
 * Display usage of script file.
 */

void
DisplayUsage(char ** argv)
{
    char * opts[] = {
"OPTIONS:",
" -a S  api --  API for I/O [POSIX|MPIIO|HDF5|NCMPI]",
" -b N  blockSize -- contiguous bytes to write per task  (e.g.: 8, 4k, 2m, 1g)",
" -B    useO_DIRECT -- uses O_DIRECT for POSIX, bypassing I/O buffers",
" -c    collective -- collective I/O",
" -C    reorderTasks -- changes task ordering to n+1 ordering [!HDF5]",
" -d N  interTestDelay -- delay between reps in seconds",
" -e    fsync -- perform fsync after POSIX write close",
" -E    useExistingTestFile -- do not remove test file before access",
" -f S  scriptFile -- test script name",
" -F    filePerProc -- file-per-process",
" -g    intraTestBarriers -- use barriers between open, write/read, and close",
" -h    showHelp -- displays options and help",
" -H    showHints -- show hints",
" -i N  repetitions -- number of repetitions of test",
" -I    individualDataSets -- datasets not shared by all procs [not working]",
" -k    keepFile -- keep testFile(s) on program exit",
" -l    storedFileOffset -- use file offset as stored signature",
" -m    multiFile -- use number of reps (-i) for multiple file count",
" -n    noFill -- no fill in HDF5 file creation",
" -N N  numTasks -- number of tasks that should participate in the test",
" -o S  testFileName -- full name for test",
" -O    options -- options string",
" -p    preallocate -- preallocate file size",
" -P    useSharedFilePointer -- use shared file pointer [not working]",
" -q    quitOnError -- during file error-checking, abort on error",
" -r    readFile -- read existing file",
" -R    checkRead -- check read after read",
" -s N  segmentCount -- number of segments",
" -S    useStridedDatatype -- put strided access into datatype [not working]",
" -t N  transferSize -- size of transfer in bytes (e.g.: 8, 4k, 2m, 1g)",
" -T    maxTimeDuration -- max time in minutes to run tests",
" -u    uniqueDir -- have each task in file-per-process use unique directory",
" -U    hintsFileName -- full name for hints file",
" -v    verbose -- output information (repeating flag increases level)",
" -V    useFileView -- use MPI_File_set_view",
" -w    writeFile -- write file",
" -W    checkWrite -- check read after write",
" -x    singleXferAttempt -- do not retry transfer if incomplete",
" ",
"         NOTE: S is a string, N is an integer number.",
" ",
"" };
    int i = 0;

    fprintf(stdout, "Usage: %s [OPTIONS]\n\n", * argv);
    for (i=0; strlen(opts[i]) > 0; i++)
        fprintf(stdout, "%s\n", opts[i]);

    return;
} /* DisplayUsage() */


/******************************************************************************/
/*
 * Distribute IOR_HINTs to all tasks' environments.
 */

void
DistributeHints(void)
{
    char   hint[MAX_HINTS][MAX_STR],
           fullHint[MAX_STR],
           hintVariable[MAX_STR];
    int    hintCount                 = 0,
           i;

    if (rank == 0) {
        for (i = 0; environ[i] != NULL; i++) {
            if (strncmp(environ[i], "IOR_HINT", strlen("IOR_HINT")) == 0) {
                hintCount++;
                if (hintCount == MAX_HINTS) {
                    fprintf(stdout, "WARNING: Exceeded max hints; %s\n",
                            "try resetting MAX_HINTS and recompiling");
                    hintCount = MAX_HINTS;
                    break;
                }
                /* assume no IOR_HINT is greater than MAX_STR in length */
                strncpy(hint[hintCount-1], environ[i], MAX_STR-1);
            }
        }
    }

    MPI_CHECK(MPI_Bcast(&hintCount, sizeof(hintCount), MPI_BYTE,
                        0, MPI_COMM_WORLD), "cannot broadcast hints");
    for (i = 0; i < hintCount; i++) {
        MPI_CHECK(MPI_Bcast(&hint[i], MAX_STR, MPI_BYTE,
                            0, MPI_COMM_WORLD), "cannot broadcast hints");
        strcpy(fullHint, hint[i]);
        strcpy(hintVariable, strtok(fullHint, "="));
        if (getenv(hintVariable) == NULL) {
            /* doesn't exist in this task's environment; better set it */
            if (putenv(hint[i]) != 0) ERR("cannot set environment variable");
        }
    }
} /* DistributeHints() */


/******************************************************************************/
/*
 * Fill "buffer", which is "size" bytes long, with known values.
 * Store the "fillrank" in the top upper bits, and a counter in the remaining
 * lower bits (LOWER_BITS).  Note that the max storable offset in the signature
 * will be 2^LOWER_BITS.
 */

void
FillBuffer(void               * buffer,
	   unsigned long        size,
           unsigned long long   offset,
           int                  fillrank)
{
    unsigned long long count, hi, lo, lomask;
    unsigned long long *buf = (unsigned long long *)buffer;

    lomask = -1ULL >> (sizeof(unsigned long long)*8 - LOWER_BITS);
    hi = fillrank;
    hi = hi << LOWER_BITS;
    for (count = 0; count < size / sizeof(unsigned long long); count++) {
	lo = (offset + (count * sizeof(unsigned long long))) & lomask;
	buf[count] = hi | lo;
    }
} /* FillBuffer() */


/******************************************************************************/
/*
 * Return string describing machine name and type.
 */
     
void
GetPlatformName(char * platformName)
{
    char             nodeName[MAX_STR],
                   * p,
                   * start,
                     sysName[MAX_STR];
    struct utsname   name;

    if (uname(&name) != 0) ERR("cannot get platform name");
    sprintf(sysName, "%s", name.sysname);
    sprintf(nodeName, "%s", name.nodename);

    start = nodeName;
    if (strlen(nodeName) == 0) {
        p = start;
    } else {
        /* point to one character back from '\0' */
        p = start + strlen(nodeName) - 1;
    }
    /*
     * to cut off trailing node number, search backwards
     * for the first non-numeric character
     */
    while (p != start) {
        if (* p < '0' || * p > '9') {
            * (p+1) = '\0';
            break;
        } else {
            p--;
        }
    }

    sprintf(platformName, "%s(%s)", nodeName, sysName);
} /* GetPlatformName() */


/******************************************************************************/
/*
 * Return test file name to access.
 */

void
GetTestFileName(char * testFileName, IOR_param_t * test)
{
    char ** fileNames,
            testFileNameRoot[MAX_STR],
            tmpString[MAX_STR];
    int     count;

    /* parse filename for multiple file systems */
    fileNames = ParseFileName(test->testFileName, &count);
    if (count > 1 && test->uniqueDir == TRUE)
	ERR("cannot use multiple file names with unique directories");
    if (test->filePerProc) {
        strcpy(testFileNameRoot,
               fileNames[((rank+rankOffset)%test->numTasks) % count]);
    } else {
        strcpy(testFileNameRoot, fileNames[0]);
    }

    /* give unique name if using multiple files */
    if (test->filePerProc) {
        /*
         * prepend rank subdirectory before filename
	 * e.g., /dir/file => /dir/<rank>/file
         */
	if (test->uniqueDir == TRUE) {
	    strcpy(testFileNameRoot, PrependDir(testFileNameRoot));
	}
	/*if (rank >= 8)
	  sprintf(testFileNameRoot, "/home/morrone/tmp/data/ior");*/
        sprintf(testFileName, "%s.%08d", testFileNameRoot,
                (rank+rankOffset)%test->numTasks); 
    } else {
	strcpy(testFileName, testFileNameRoot);
    }

    /* add suffix for multiple files */
    if (test->repCounter > -1) {
        sprintf(tmpString, ".%d", test->repCounter);
	strcat(testFileName, tmpString);
    }
} /* GetTestFileName() */


/******************************************************************************/
/*
 * Get time stamp.  Use MPI_Timer() unless _NO_MPI_TIMER is defined,
 * in which case use gettimeofday().
 */

double
GetTimeStamp(void)
{
    double         timeVal;
#ifdef _NO_MPI_TIMER
    struct timeval timer;

    if (gettimeofday(&timer, (struct timezone *)NULL) != 0)
        ERR("cannot use gettimeofday()");
    timeVal = (double)timer.tv_sec + ((double)timer.tv_usec/1000000);
#else /* not _NO_MPI_TIMER */
    timeVal = MPI_Wtime();
    if (timeVal <= 0) ERR("cannot use MPI_Wtime()");
#endif /* _NO_MPI_TIMER */
    return(timeVal);
} /* GetTimeStamp() */


/******************************************************************************/
/*
 * Convert IOR_offset_t value to human readable string.
 */

char *
HumanReadable(IOR_offset_t value, int base)
{
    char * valueStr;
    int m = 0, g = 0;
    char m_str[8], g_str[8];

    valueStr = (char *)malloc(MAX_STR);
    if (valueStr == NULL) ERR("out of memory");

    if (base == BASE_TWO) {
        m = MEBIBYTE;
        g = GIBIBYTE;
        strcpy(m_str, "MiB");
        strcpy(g_str, "GiB");
    } else if (base == BASE_TEN) {
        m = MEGABYTE;
        g = GIGABYTE;
        strcpy(m_str, "MB");
        strcpy(g_str, "GB");
    }

    if (value >= g) {
        if (value % (IOR_offset_t)g) {
            sprintf(valueStr, "%.2f %s", (double)((double)value/g), g_str);
        } else {
            sprintf(valueStr, "%d %s", (int)(value/g), g_str);
        }
    } else if (value >= m) {
        if (value % (IOR_offset_t)m) {
            sprintf(valueStr, "%.2f %s", (double)((double)value/m), m_str);
        } else {
            sprintf(valueStr, "%d %s", (int)(value/m), m_str);
        }
    } else if (value >= 0) {
        sprintf(valueStr, "%d bytes", (int)value);
    } else {
        sprintf(valueStr, "-");
    }
    return valueStr;
} /* HumanReadable() */


/******************************************************************************/
/*
 * Change string to lower case.
 */

char *
LowerCase(char * string)
{
    char * nextChar = string;

    while (* nextChar != '\0') {
        * nextChar = (char)tolower((int)* nextChar);
        nextChar++;
    }
    return(string);
} /* LowerCase() */


/******************************************************************************/
/*
 * Parse file name.
 */

char **
ParseFileName(char * name, int * count)
{
    char ** fileNames,
          * tmp,
          * token;
    int     i          = 0;

    * count = 0;
    tmp = name;

    /* pass one */
    /* if something there, count the first item */
    if (* tmp != '\0') {
        (* count)++;
    }
    /* count the rest of the filenames */
    while (* tmp != '\0') {
        if (* tmp == ':') {
             (* count)++;
        }
        tmp++;
    }

    fileNames = (char **)malloc((* count) * sizeof(char **));
    if (fileNames == NULL) ERR("out of memory");

    /* pass two */
    token = strtok(name, ":");
    while (token != NULL) {
        fileNames[i] = token;
        token = strtok(NULL, ":");
        i++;
    }
    return(fileNames);
} /* ParseFileName() */


/******************************************************************************/
/*
 * Pretty Print a Double.  The First parameter is a flag determining if left
 * justification should be used.  The third parameter a null-terminated string
 * that should be appended to the number field.
 */

void
PPDouble(int      leftjustify,
         double   number,
         char   * append)
{
    if (number < 0) {
        fprintf(stdout, "   -      %s", append);
    } else {
        if (leftjustify) {
            if (number < 1)
                fprintf(stdout, "%-10.6f%s", number, append);
            else if (number < 3600)
                fprintf(stdout, "%-10.2f%s", number, append);
            else
                fprintf(stdout, "%-10.0f%s", number, append);
        } else {
            if (number < 1)
                fprintf(stdout, "%10.6f%s", number, append);
            else if (number < 3600)
                fprintf(stdout, "%10.2f%s", number, append);
            else
                fprintf(stdout, "%10.0f%s", number, append);
        }
    }
} /* PPDouble() */


/******************************************************************************/
/*
 * From absolute directory, insert rank as subdirectory.  Allows each task
 * to write to its own directory.  E.g., /dir/file => /dir/<rank>/file.
 * 
 */

char *
PrependDir(char * rootDir)
{
    char * dir;
    char   fname[MAX_STR+1];
    char * p;
    int    i;

    dir = (char *)malloc(MAX_STR+1);
    if (dir == NULL) ERR("out of memory");

    /* get dir name */
    strcpy(dir, rootDir);
    i = strlen(dir)-1;
    while (i > 0) {
        if (dir[i] == '\0' || dir[i] == '/') {
            dir[i] = '/';
            dir[i+1] = '\0';
            break;
        }
        i--;
    }

    /* get file name */
    strcpy(fname, rootDir);
    p = fname;
    while (i > 0) {
        if (fname[i] == '\0' || fname[i] == '/') {
            p = fname + (i+1);
            break;
        }
        i--;
    }

    /* create directory with rank as subdirectory */
        sprintf(dir, "%s%d", dir, (rank+rankOffset)%numTasksWorld);

    /* dir doesn't exist, so create */
    if (access(dir, F_OK) != 0) {
        if (mkdir(dir, S_IRWXU) < 0 ) {
            ERR("error: cannot create directory");
        }

    /* check if correct permissions */
    } else if (access(dir, R_OK) != 0 || access(dir, W_OK) != 0 ||
               access(dir, X_OK) != 0) {
        ERR("error: invalid directory permissions");
    }

    /* concatenate dir and file names */
    strcat(dir, "/");
    strcat(dir, p);

    return dir;
} /* PrependDir() */


/******************************************************************************/
/*
 * Reduce test results, and show if verbose set.
 */

void
ReduceIterResults(IOR_param_t  * test,
                  double      ** timer,
                  int            rep,
                  int            access)
{
    double       reduced[12],
                 diff[6],
                 currentWrite,
                 currentRead,
                 totalWriteTime,
                 totalReadTime;
    enum         {RIGHT, LEFT};
    int          i;
    static int   firstIteration          = TRUE;
    IOR_offset_t actualFileSize;
    MPI_Op       op;

    /* Find the minimum start time of the even numbered timers, and the
       maximum finish time for the odd numbered timers */
    for (i = 0; i < 12; i++) {
        op = i % 2 ? MPI_MAX : MPI_MIN;
        MPI_CHECK(MPI_Reduce(&timer[i][rep], &reduced[i], 1, MPI_DOUBLE,
                             op, 0, testComm),
		  "MPI_Reduce()");
    }

    if (rank == 0) {
	/* Calculate elapsed times and throughput numbers */
        for (i = 0; i < 6; i++)
	    diff[i] = reduced[2*i+1] - reduced[2*i];
        totalReadTime  = reduced[11] - reduced[6];
        totalWriteTime = reduced[5] - reduced[0];
        actualFileSize = test->actualFileSize;
        if (test->filePerProc == TRUE)
            actualFileSize *= test->numTasks;
        currentWrite = (double)((double)actualFileSize / totalWriteTime);
        currentRead = (double)((double)actualFileSize / totalReadTime);
        if (access == WRITE)
            test->writeVal[rep] = currentWrite;
        if (access == READ)
            test->readVal[rep] = currentRead;
    }

    if (rank == 0) {
        /* print out the results */
	if (firstIteration && rep == 0) {
            fprintf(stdout, "access    bw(MiB/s)  block(KiB) xfer(KiB)");
            fprintf(stdout, "  open(s)    wr/rd(s)   close(s)   iter\n");
            fprintf(stdout, "------    ---------  ---------- ---------");
            fprintf(stdout, "  --------   --------   --------   ----\n");
        }
	if (access == WRITE) {
            fprintf(stdout, "write     ");
            PPDouble(LEFT, (currentWrite/MEBIBYTE), " \0");
            PPDouble(LEFT, (double)test->blockSize/KIBIBYTE, " \0");
            PPDouble(LEFT, (double)test->transferSize/KIBIBYTE, " \0");
            if (test->writeFile) {
                PPDouble(LEFT, diff[0], " \0");
                PPDouble(LEFT, diff[1], " \0");
                PPDouble(LEFT, diff[2], " \0");
            }
            fprintf(stdout, "%-4d\n", rep);
        }
	if (access == READ) {
            fprintf(stdout, "read      ");
            PPDouble(LEFT, (currentRead/MEBIBYTE), " \0");
            PPDouble(LEFT, (double)test->blockSize/KIBIBYTE, " \0");
            PPDouble(LEFT, (double)test->transferSize/KIBIBYTE, " \0");
            if (test->readFile) {
                PPDouble(LEFT, diff[3], " \0");
                PPDouble(LEFT, diff[4], " \0");
                PPDouble(LEFT, diff[5], " \0");
            }
            fprintf(stdout, "%-4d\n", rep);
        }
        fflush(stdout);
    }
    firstIteration = FALSE;  /* set to TRUE to repeat this header */
} /* ReduceIterResults() */


/******************************************************************************/
/*
 * Check for file(s), then remove all files if file-per-proc, else single file.
 */
     
void
RemoveFile(char * testFileName,
           int    filePerProc)
{
    if (filePerProc) {
        if (access(testFileName, F_OK) == 0) {
            IOR_Delete(testFileName);
        }
    } else {
        if ((rank == 0) && (access(testFileName, F_OK) == 0)) {
            IOR_Delete(testFileName);
        }
    }
} /* RemoveFile() */


/******************************************************************************/
/*
 * Setup tests by parsing commandline and creating test script.
 */

IOR_queue_t *
SetupTests(int argc, char ** argv)
{
    IOR_queue_t * tests,
                * testsHead;

    /* count the tasks per node */
    tasksPerNode = CountTasksPerNode();

    testsHead = tests = ParseCommandLine(argc, argv);
    /*
     * Since there is no guarantee that anyone other than
     * task 0 has the environment settings for the hints, pass
     * the hint=value pair to everyone else in MPI_COMM_WORLD
     */
    DistributeHints();

    /* check validity of tests and create test queue */
    while (tests != NULL) {
        ValidTests(&tests->testParameters);
        tests = tests->nextTest;
    }

    wall_clock_deviation = TimeDeviation();
    if (rank == 0 && wall_clock_deviation > 15) {
	fprintf(stdout, "WARNING: Time deviation between nodes exceeds 15 seconds!!!\n");
    }

    return(testsHead);
} /* SetupTests() */


/******************************************************************************/
/*
 * Print header information for test output.
 */

void
ShowInfo(int argc, char **argv)
{
    time_t   currentTime;
    char   * currentTimePtr;
    int      i;
    struct utsname unamebuf;

    fprintf(stdout, "%s: MPI Coordinated Test of Parallel I/O\n\n",
            IOR_RELEASE);

    if ((currentTime = time(NULL)) == -1) ERR("cannot get current time");
    if ((currentTimePtr = ctime(&currentTime)) == NULL)
        ERR("cannot read current time");
    fprintf(stdout, "Run began: %s", currentTimePtr);
    fprintf(stdout, "Command line used:");
    for (i = 0; i < argc; i++) {
        fprintf(stdout, " %s", argv[i]);
    }
    fprintf(stdout, "\n");
    if (uname(&unamebuf) == -1) ERR("uname failed");
    fprintf(stdout, "Machine: %s %s", unamebuf.sysname, unamebuf.nodename);
    if (verbose >= MED_VERBOSE) {
        fprintf(stdout, " %s %s %s", unamebuf.release, unamebuf.version,
	        unamebuf.machine);
    }
    fprintf(stdout, "\n");
#ifdef _NO_MPI_TIMER
    if (verbose >= MED_VERBOSE)
	fprintf(stdout, "Using unsynchronized POSIX timer\n");
#else /* not _NO_MPI_TIMER */
    if (MPI_WTIME_IS_GLOBAL) {
	if (verbose >= MED_VERBOSE)
	    fprintf(stdout, "Using synchronized MPI timer\n");
    } else {
        if (verbose >= MED_VERBOSE)
	    fprintf(stdout, "Using unsynchronized MPI timer\n");
    }
#endif /* _NO_MPI_TIMER */
    if (verbose >= LOW_VERBOSE) {
        fprintf(stdout, "Maximum wall clock deviation: %.02f sec\n",
	    wall_clock_deviation);
        DisplayFreespace(argc, argv);
    }
    if (verbose >= ALL_VERBOSE) system("env");
    fflush(stdout);
} /* ShowInfo() */


/******************************************************************************/
/*
 * Show simple test output with max results for iterations.
 */

void
ShowSetup(IOR_param_t * test)
{
    IOR_offset_t aggregateFileSize;

    aggregateFileSize = test->expectedFileSize;
    if (test->filePerProc == TRUE) {
        aggregateFileSize *= test->numTasks;
    }

    if (strcmp(test->debug, "") != 0) {
        fprintf(stdout, "\n*** DEBUG MODE ***\n");
        fprintf(stdout, "*** %s ***\n\n", test->debug);
    }
    fprintf(stdout, "\nSummary:\n");
    fprintf(stdout, "\tapi                = %s\n",
            test->apiVersion);
    fprintf(stdout, "\ttest filename      = %s\n", test->testFileName);
    fprintf(stdout, "\taccess             = ");
    if (test->filePerProc) {
        fprintf(stdout, "file-per-process");
    } else {
        fprintf(stdout, "single-shared-file");
    }
    if (verbose >= LOW_VERBOSE && strcmp(test->api, "POSIX") != 0) {
        if (test->collective == FALSE) {
            fprintf(stdout, ", independent");
        } else {
            fprintf(stdout, ", collective");
        }
    }
    fprintf(stdout, "\n");
    if (verbose >= LOW_VERBOSE) {
        if (test->segmentCount > 1) {
            fprintf(stdout, "\tpattern            = strided (%d segments)\n",
            (int)test->segmentCount);
        } else {
            fprintf(stdout, "\tpattern            = segmented (1 segment)\n");
        }
    }
    fprintf(stdout, "\tclients            = %d (%d per node)\n",
            test->numTasks, tasksPerNode);
    fprintf(stdout, "\trepetitions        = %d\n",
            test->repetitions);
    fprintf(stdout, "\txfersize           = %s\n",
            HumanReadable(test->transferSize, BASE_TWO));
    fprintf(stdout, "\tblocksize          = %s\n",
            HumanReadable(test->blockSize, BASE_TWO));
    fprintf(stdout, "\taggregate filesize = %s\n",
            HumanReadable(aggregateFileSize, BASE_TWO));
#ifdef _USE_LUSTRE
    fprintf(stdout, "\tLustre stripe size = %s\n",
            ((test->lustre_stripe_size == 0) ? "Use default" :
            HumanReadable(test->lustre_stripe_size, BASE_TWO)));
    if (test->lustre_stripe_count == 0) {
        fprintf(stdout, "\t      stripe count = %s\n", "Use default");
    } else {
        fprintf(stdout, "\t      stripe count = %d\n",
                test->lustre_stripe_count);
    }
#endif /* _USE_LUSTRE */
    fprintf(stdout, "\n");
    /*fprintf(stdout, "\n  ================================\n\n");*/
    fflush(stdout);
} /* ShowSetup() */


/******************************************************************************/
/*
 * Show test description.
 */

void
ShowTest(IOR_param_t * test)
{
    fprintf(stdout, "\n\n  ================================\n\n");
    fprintf(stdout, "TEST:\t%s=%d\n", "id", test->id);
    fprintf(stdout, "\t%s=%s\n", "api", test->api);
    fprintf(stdout, "\t%s=%s\n", "platform", test->platform);
    fprintf(stdout, "\t%s=%s\n", "testFileName", test->testFileName);
    fprintf(stdout, "\t%s=%s\n", "hintsFileName", test->hintsFileName);
    fprintf(stdout, "\t%s=%d\n", "maxTimeDuration", test->maxTimeDuration);
    fprintf(stdout, "\t%s=%s\n", "options", test->options);
    fprintf(stdout, "\t%s=%d\n", "nodes", test->nodes);
    fprintf(stdout, "\t%s=%d\n", "tasksPerNode", test->tasksPerNode);
    fprintf(stdout, "\t%s=%d\n", "repetitions", test->repetitions);
    fprintf(stdout, "\t%s=%d\n", "multiFile", test->multiFile);
    fprintf(stdout, "\t%s=%d\n", "interTestDelay", test->interTestDelay);
    fprintf(stdout, "\t%s=%d\n", "fsync", test->fsync);
    fprintf(stdout, "\t%s=%d\n", "useExistingTestFile",
	    test->useExistingTestFile);
    fprintf(stdout, "\t%s=%d\n", "showHints", test->showHints);
    fprintf(stdout, "\t%s=%d\n", "uniqueDir", test->uniqueDir);
    fprintf(stdout, "\t%s=%d\n", "showHelp", test->showHelp);
    fprintf(stdout, "\t%s=%d\n", "individualDataSets",test->individualDataSets);
    fprintf(stdout, "\t%s=%d\n", "singleXferAttempt", test->singleXferAttempt);
    fprintf(stdout, "\t%s=%d\n", "readFile", test->readFile);
    fprintf(stdout, "\t%s=%d\n", "writeFile", test->writeFile);
    fprintf(stdout, "\t%s=%d\n", "filePerProc", test->filePerProc);
    fprintf(stdout, "\t%s=%d\n", "reorderTasks", test->reorderTasks);
    fprintf(stdout, "\t%s=%d\n", "checkWrite", test->checkWrite);
    fprintf(stdout, "\t%s=%d\n", "checkRead", test->checkRead);
    fprintf(stdout, "\t%s=%d\n", "preallocate", test->preallocate);
    fprintf(stdout, "\t%s=%d\n", "useFileView", test->useFileView);
    fprintf(stdout, "\t%s=%d\n", "storeFileOffset", test->storeFileOffset);
    fprintf(stdout, "\t%s=%d\n", "useSharedFilePointer",
	    test->useSharedFilePointer);
    fprintf(stdout, "\t%s=%d\n", "useO_DIRECT", test->useO_DIRECT);
    fprintf(stdout, "\t%s=%d\n", "useStridedDatatype", test->useStridedDatatype);
    fprintf(stdout, "\t%s=%d\n", "keepFile", test->keepFile);
    fprintf(stdout, "\t%s=%d\n", "quitOnError", test->quitOnError);
    fprintf(stdout, "\t%s=%d\n", "verbose", verbose);
    fprintf(stdout, "\t%s=%d\n", "collective", test->collective);
    fprintf(stdout, "\t%s=%ld", "segmentCount", (long)test->segmentCount);
    if (strcmp(test->api, "HDF5") == 0) {
        fprintf(stdout, " (datasets)");
    }
    fprintf(stdout, "\n");
    fprintf(stdout, "\t%s=%ld\n", "transferSize", (long)test->transferSize);
    fprintf(stdout, "\t%s=%lld\n", "blockSize", (long long)test->blockSize);
} /* ShowTest() */


/******************************************************************************/
/*
 * Takes a string of the form 64, 8m, 128k, 4g, etc. and converts to bytes.
 */

IOR_offset_t
StringToBytes(char * size_str)
{
    IOR_offset_t size = 0;
    char range;
    int rc;

    rc = sscanf(size_str, "%lld%c", &size, &range);
    if (rc == 2) {
        switch ((int)range) {
        case 'k': case 'K': size <<= 10; break;
        case 'm': case 'M': size <<= 20; break;
        case 'g': case 'G': size <<= 30; break;
        }
    } else if (rc == 0) {
        size = -1;
    }
    return(size);
} /* StringToBytes() */


/******************************************************************************/
/*
 * Summarize results, showing max rates (and min, mean, stddev if verbose)
 */

void
SummarizeResults(IOR_param_t * test)
{
    int    rep;
    double maxWrite, minWrite, maxRead, minRead,
           meanWrite, meanRead,
           varWrite = 0, varRead = 0,
           sdWrite = 0, sdRead = 0,
           sumWrite = 0, sumRead = 0;

    maxWrite = minWrite = test->writeVal[0];
    maxRead = minRead = test->readVal[0];

    for (rep = 0; rep < test->repetitions; rep++) {
        if (maxWrite < test->writeVal[rep]) {
            maxWrite = test->writeVal[rep];
        }
        if (maxRead < test->readVal[rep]) {
            maxRead = test->readVal[rep];
        }
        if (minWrite > test->writeVal[rep]) {
            minWrite = test->writeVal[rep];
        }
        if (minRead > test->readVal[rep]) {
            minRead = test->readVal[rep];
        }
        sumWrite += test->writeVal[rep];
        sumRead += test->readVal[rep];
    }

    meanWrite = sumWrite / test->repetitions;
    meanRead = sumRead / test->repetitions;

    for (rep = 0; rep < test->repetitions; rep++) {
        varWrite += pow((meanWrite - test->writeVal[rep]), 2);
        varRead += pow((meanRead - test->readVal[rep]), 2);
    }
    varWrite = varWrite / test->repetitions;
    varRead = varRead / test->repetitions;
    sdWrite = sqrt(varWrite);
    sdRead = sqrt(varRead);

    if (rank == 0 && verbose >= MED_VERBOSE) {
        fprintf(stdout,"\n");
        fprintf(stdout,"Operation  Max (MiB)  Min (MiB)  Mean (MiB)   Std Dev\n");
        fprintf(stdout,"---------  ---------  ---------  ----------   -------\n");
        fprintf(stdout,"%s     ", "write");
        fprintf(stdout,"%10.2f ", maxWrite/MEBIBYTE);
        fprintf(stdout,"%10.2f  ", minWrite/MEBIBYTE);
        fprintf(stdout,"%10.2f", meanWrite/MEBIBYTE);
        fprintf(stdout,"%10.2f\n", sdWrite/MEBIBYTE);
        fprintf(stdout,"%s      ", "read");
        fprintf(stdout,"%10.2f ", maxRead/MEBIBYTE);
        fprintf(stdout,"%10.2f  ", minRead/MEBIBYTE);
        fprintf(stdout,"%10.2f", meanRead/MEBIBYTE);
        fprintf(stdout,"%10.2f\n", sdRead/MEBIBYTE);
        fflush(stdout);
    }

    if (rank == 0) {
        fprintf(stdout, "\n");
        if (test->writeFile) {
            fprintf(stdout, "Max Write: %.2f MiB/sec (%.2f MB/sec)\n",
                    maxWrite/MEBIBYTE, maxWrite/MEGABYTE);
        }
        if (test->readFile) {
            fprintf(stdout, "Max Read:  %.2f MiB/sec (%.2f MB/sec)\n",
                    maxRead/MEBIBYTE, maxRead/MEGABYTE);
        }
        fprintf(stdout, "\n");
    }
} /* SummarizeResults() */


/******************************************************************************/
/*
 * Using the test parameters, run iteration(s) of single test.
 */
void
TestIoSys(IOR_param_t *test)
{
    char           localhost[MAX_STR],
                   testFileName[MAX_STR];
    double       * timer[12];
    double         startTime;
    int            i,
                   rep,
		   maxTimeDuration;
    struct stat    stat_buf;
    void         * fd;
    IOR_offset_t   actualFileSize,
                   expectedFileSize;
    MPI_Group      orig_group, new_group;
    int            range[3];
    int            testRank;

    /* set up communicator for test */
    if (test->numTasks > numTasksWorld) {
        if (rank == 0)
	    fprintf(stdout, "WARNING: More tasks requested (%d) than available (%d), running on %d tasks.\n",
		    test->numTasks, numTasksWorld, numTasksWorld);
	test->numTasks = numTasksWorld;
    }
    MPI_Comm_group(MPI_COMM_WORLD, &orig_group);
    range[0] = 0; /* first rank */
    range[1] = test->numTasks - 1; /* last rank */
    range[2] = 1; /* stride */
    MPI_Group_range_incl(orig_group, 1, &range, &new_group);
    MPI_Comm_create(MPI_COMM_WORLD, new_group, &testComm);
    if (testComm == MPI_COMM_NULL) {
        /* tasks not in the group do not participate in this test */
        MPI_Barrier(MPI_COMM_WORLD);
	return;
    }
    if (rank == 0)
	fprintf(stdout, "Participating tasks: %d\n", test->numTasks);
    /* setup timers */
    for (i = 0; i < 12; i++) {
        timer[i] = (double *)malloc(test->repetitions * sizeof(double));
        if (timer[i] == NULL) ERR("out of memory");
    }

    test->writeVal = (double *)malloc(test->repetitions * sizeof(double));
    test->readVal = (double *)malloc(test->repetitions * sizeof(double));

    /* bind I/O calls to specific API */
    AioriBind(test->api);

    /* file size is first calculated on a per-process basis */
    test->expectedFileSize = test->blockSize * test->segmentCount;
    if (test->filePerProc == FALSE) {
        test->expectedFileSize *= test->numTasks;
    }

    if (rank == 0) ShowSetup(test);

    startTime = GetTimeStamp();
    maxTimeDuration = test->maxTimeDuration * 60;	/* convert to seconds */

    for (rep = 0; rep < test->repetitions; rep++) {
	/* use repetition count for number of multiple files */
        if (test->multiFile) test->repCounter = rep;

        /*
         * write the file(s), getting timing between I/O calls
         */

        if (test->writeFile
	  && (maxTimeDuration ? (GetTimeStamp() - startTime < maxTimeDuration) : 1)) {
            GetTestFileName(testFileName, test);
            if (verbose >= HIGH_VERBOSE) {
                fprintf(stdout, "task %d writing %s\n", rank, testFileName);
	    }
            DelaySecs(test->interTestDelay);
            if (test->useExistingTestFile == FALSE) {
                RemoveFile(testFileName, test->filePerProc);
            }
            MPI_CHECK(MPI_Barrier(testComm), "barrier error");
            test->open = WRITE;
            timer[0][rep] = GetTimeStamp();
            fd = IOR_Create(testFileName, test);
            timer[1][rep] = GetTimeStamp();
	    if (test->intraTestBarriers)
		MPI_Barrier(testComm);
	    if (rank == 0 && verbose >= LOW_VERBOSE)
		fprintf(stdout, "Commencing write performance test.\n");
            timer[2][rep] = GetTimeStamp();
            WriteOrRead(test, fd, WRITE);
            timer[3][rep] = GetTimeStamp();
	    if (test->intraTestBarriers)
		MPI_Barrier(testComm);
            timer[4][rep] = GetTimeStamp();
            IOR_Close(fd, test);
            timer[5][rep] = GetTimeStamp();
            MPI_CHECK(MPI_Barrier(testComm), "barrier error");

            /*
             * check the size of the file just written
             * NOTE:  This is just a warning since the total
             *        file size may not be registered yet.
             */
            if (stat(testFileName, &stat_buf) != 0) {
                ERR("cannot get status of written file");
            }
            test->actualFileSize = stat_buf.st_size;
            actualFileSize = test->actualFileSize;
            expectedFileSize = test->expectedFileSize;

            /*
	     * if HDF5 or NCMPI, add header size to expected file size
	     * for true measurement of expected file size
	     */
            if (strcmp(test->api, "HDF5") == 0 ||
                strcmp(test->api, "NCMPI") == 0) {
                expectedFileSize = actualFileSize;
            }

            if (actualFileSize != expectedFileSize) {
                if (rank == 0 ||
                    test->filePerProc == TRUE) {
                    fprintf(stdout, "WARNING: Expected file size = %lld.\n",
                            (long long)expectedFileSize);
                    fprintf(stdout, "WARNING: Actual file size   = %lld.\n",
                            (long long)actualFileSize);
                }
            }
	    if (verbose >= HIGH_VERBOSE) WriteTimes(test, timer, rep, WRITE);
            ReduceIterResults(test, timer, rep, WRITE);
        }
        /*
         * perform a check of data, reading back data and comparing
         * against what was expected to be written
         */
        if (test->checkWrite
	  && (maxTimeDuration ? (GetTimeStamp() - startTime < maxTimeDuration) : 1)) {
            MPI_CHECK(MPI_Barrier(testComm), "barrier error");
	    /* intentionally corrupt file to determine if check works */
            if ((CORRUPT_FILE == TRUE) && (rank == 0 || test->filePerProc)) {
                CorruptTheFile(testFileName,
		  /* offset */
                  (123456789+(test->transferSize+15)*rank) % expectedFileSize,
                  /* byteValue */
                  121);
            }
            MPI_CHECK(MPI_Barrier(testComm), "barrier error");
            if (rank == 0 && verbose >= LOW_VERBOSE)
		fprintf(stdout,
			"Verifying contents of the file(s) just written.\n");
            if (test->reorderTasks) {
		/* move two nodes away from writing node */
		rankOffset = (2*tasksPerNode) % test->numTasks;
	    }
            GetTestFileName(testFileName, test);
            test->open = WRITECHECK;
            fd = IOR_Open(testFileName, test);
            WriteOrRead(test, fd, WRITECHECK);
            IOR_Close(fd, test);
	    rankOffset = 0;
        }
        /*
         * read the file(s), getting timing between I/O calls
         */
        if (test->readFile
	  && (maxTimeDuration ? (GetTimeStamp() - startTime < maxTimeDuration) : 1)) {
            if (test->reorderTasks) {
		/* move one node away from writing node */
		rankOffset = (1*tasksPerNode) % test->numTasks;
	    }
	    GetTestFileName(testFileName, test);

            if (verbose >= HIGH_VERBOSE) {
                fprintf(stdout, "task %d reading %s\n", rank, testFileName);
            }
            DelaySecs(test->interTestDelay);
            MPI_CHECK(MPI_Barrier(testComm), "barrier error");
            test->open = READ;
            timer[6][rep] = GetTimeStamp();
            fd = IOR_Open(testFileName, test);
            timer[7][rep] = GetTimeStamp();
	    if (test->intraTestBarriers)
		MPI_Barrier(testComm);
	    if (rank == 0 && verbose >= LOW_VERBOSE)
		fprintf(stdout, "Commencing read performance test.\n");
            timer[8][rep] = GetTimeStamp();
            WriteOrRead(test, fd, READ);
            timer[9][rep] = GetTimeStamp();
	    if (test->intraTestBarriers)
		MPI_Barrier(testComm);
            timer[10][rep] = GetTimeStamp();
            IOR_Close(fd, test);
            timer[11][rep] = GetTimeStamp();
            if (test->writeFile != TRUE) {
                /* since read-only, didn't get file size during write */
                if (stat(testFileName, &stat_buf) != 0) {
                    ERR("cannot get status of written file");
                }
	        test->actualFileSize = stat_buf.st_size;
            }
            if (verbose >= HIGH_VERBOSE) WriteTimes(test, timer, rep, READ);
            ReduceIterResults(test, timer, rep, READ);
        }

        /*
         * perform a check of data, reading back data twice and
         * comparing against what was expected to be read
         */
        if (test->checkRead
	  && (maxTimeDuration ? (GetTimeStamp() - startTime < maxTimeDuration) : 1)) {
            MPI_CHECK(MPI_Barrier(testComm), "barrier error");
            if (rank == 0 && verbose >= LOW_VERBOSE)
		fprintf(stdout, "Re-reading the file(s) twice to verify that reads are consistent.\n");
            if (test->reorderTasks) {
		/* move one node away from reading node */
		rankOffset = (3*tasksPerNode) % test->numTasks;
	    }
            GetTestFileName(testFileName, test);
            MPI_CHECK(MPI_Barrier(testComm), "barrier error");
            test->open = READCHECK;
            fd = IOR_Open(testFileName, test);
            WriteOrRead(test, fd, READCHECK);
            IOR_Close(fd, test);
        }
        /*
         * this final barrier may not be necessary as IOR_Close should
         * be a collective call -- but to make sure that the file has
         * has not be removed by a task before another finishes writing,
         * the MPI_Barrier() call has been included.
         */
        MPI_CHECK(MPI_Barrier(testComm), "barrier error");
        if (!test->keepFile) {
            RemoveFile(testFileName, test->filePerProc);
        }
        MPI_CHECK(MPI_Barrier(testComm), "barrier error");
	rankOffset = 0;
    }

    SummarizeResults(test);

    MPI_Comm_free(&testComm);
    free(test->writeVal);
    free(test->readVal);
    for (i = 0; i < 12; i++) {
        free(timer[i]);
    }
    /* Sync with the tasks that did not participate in this test */
    MPI_Barrier(MPI_COMM_WORLD);

} /* TestIoSys() */


/******************************************************************************/
/*
 * Determine any spread (range) between node times.
 */

double
TimeDeviation(void)
{
    double timestamp, min = 0, max = 0;

    MPI_Barrier(MPI_COMM_WORLD);
    timestamp = GetTimeStamp();
    MPI_CHECK(MPI_Reduce(&timestamp, &min, 1, MPI_DOUBLE,
			 MPI_MIN, 0, MPI_COMM_WORLD),
	      "cannot reduce tasks' times");
    MPI_CHECK(MPI_Reduce(&timestamp, &max, 1, MPI_DOUBLE,
			 MPI_MAX, 0, MPI_COMM_WORLD),
	      "cannot reduce tasks' times");
    return max-min;
} /* TimeDeviation() */


/******************************************************************************/
/*
 * Determine if valid tests from parameters.
 */

void
ValidTests(IOR_param_t * test)
{
    /* get the version of the tests */

    AioriBind(test->api);
    IOR_SetVersion(test);

    if (test->repetitions <= 0)
        ERR("too few test repetitions");
    if (test->numTasks <= 0)
        ERR("too few tasks for testing");
    if (test->interTestDelay < 0)
        ERR("inter-test delay must be nonnegative value");
    if (test->readFile != TRUE && test->writeFile != TRUE)
        ERR("test must read and/or write file");
    if (test->segmentCount < 0)
        ERR("segment count must be positive value");
    if ((test->blockSize % sizeof(IOR_size_t)) != 0)
        ERR("block size must be a multiple of access size");
    if (test->blockSize < 0)
        ERR("block size must be non-negative integer");
    if ((test->transferSize % sizeof(IOR_size_t)) != 0)
        ERR("transfer size must be a multiple of access size");
    if (test->transferSize < 0)
        ERR("transfer size must be non-negative integer");
    if (test->transferSize == 0) {
        if (test->blockSize != 0)
            ERR("test will not complete with zero transfer size");
    } else {
        if ((test->blockSize % test->transferSize) != 0)
            ERR("block size must be a multiple of transfer size");
    }
    if (test->blockSize < test->transferSize)
        ERR("block size must not be smaller than transfer size");
    if ((strcmp(test->api, "MPIIO") == 0)
	&& (test->blockSize < sizeof(IOR_size_t)
	    || test->transferSize < sizeof(IOR_size_t)))
        ERR("block/transfer size may not be smaller than IOR_size_t for MPIIO");
    if ((strcmp(test->api, "HDF5") == 0)
	&& (test->blockSize < sizeof(IOR_size_t)
	    || test->transferSize < sizeof(IOR_size_t)))
        ERR("block/transfer size may not be smaller than IOR_size_t for HDF5");
    if ((strcmp(test->api, "NCMPI") == 0)
	&& (test->blockSize < sizeof(IOR_size_t)
	    || test->transferSize < sizeof(IOR_size_t)))
        ERR("block/transfer size may not be smaller than IOR_size_t for NCMPI");
    if ((strcmp(test->api, "NCMPI") == 0)
        && ((test->numTasks * test->blockSize * test->segmentCount)
            > (2*(IOR_offset_t)GIBIBYTE)))
        ERR("file size must be < 2GiB");
    if((test->useFileView == TRUE)
        && (sizeof(MPI_Aint) < 8) /* used for 64-bit datatypes */
        && ((test->numTasks * test->blockSize) > (2*(IOR_offset_t)GIBIBYTE)))
        ERR("segment size must be < 2GiB");
    if ((strcmp(test->api, "POSIX") != 0) && test->singleXferAttempt)
        ERR("transfer retry only available in POSIX");
    if ((strcmp(test->api, "POSIX") != 0) && test->fsync)
        ERR("fsync() only available in POSIX");
    if ((strcmp(test->api, "MPIIO") != 0) && test->preallocate)
        ERR("preallocation only available in MPIIO");
    if ((strcmp(test->api, "MPIIO") != 0) && test->useFileView)
        ERR("file view only available in MPIIO");
    if ((strcmp(test->api, "MPIIO") != 0) && test->useSharedFilePointer)
        ERR("shared file pointer only available in MPIIO");
    if ((strcmp(test->api, "MPIIO") == 0) && test->useSharedFilePointer)
        ERR("shared file pointer not implemented");
    if ((strcmp(test->api, "MPIIO") != 0) && test->useStridedDatatype)
        ERR("strided datatype only available in MPIIO");
    if ((strcmp(test->api, "MPIIO") == 0) && test->useStridedDatatype)
        ERR("strided datatype not implemented");
    if ((strcmp(test->api, "MPIIO") == 0)
	&& test->useStridedDatatype
	&& (test->blockSize < sizeof(IOR_size_t)
	    || test->transferSize < sizeof(IOR_size_t)))
        ERR("need larger file size for strided datatype in MPIIO");
    if ((strcmp(test->api, "POSIX") == 0) && test->showHints)
        ERR("hints not available in POSIX");
    if ((strcmp(test->api, "POSIX") == 0) && test->collective)
        ERR("collective not available in POSIX");
    if ((strcmp(test->api, "HDF5") != 0) && test->individualDataSets)
        ERR("individual datasets only available in HDF5");
    if ((strcmp(test->api, "HDF5") == 0) && test->individualDataSets)
        ERR("individual data sets not implemented");
    if ((strcmp(test->api, "HDF5") == 0) && test->filePerProc)
        ERR("file-per-proc not available in current HDF5");
    if ((strcmp(test->api, "NCMPI") == 0) && test->filePerProc)
        ERR("file-per-proc not available in current NCMPI");
    if (test->noFill) {
        if (strcmp(test->api, "HDF5") != 0) {
            ERR("'no fill' option only available in HDF5");
        } else {
	#if HAVE_HDF5_NO_FILL
            ;
        #else
            char errorString[MAX_STR];
            sprintf(errorString, "'no fill' option not available in %s",
                    test->apiVersion);
            ERR(errorString);
        #endif
        }
    }
    if (test->useExistingTestFile
	&& (test->lustre_stripe_count != 0
	    || test->lustre_stripe_size != 0
	    || test->lustre_start_ost != -1))
	ERR("Lustre stripe options are incompatible with useExistingTestFile");
} /* ValidTests() */


/******************************************************************************/
/*
 * Write or Read data to file(s).  This loops through the strides, writing
 * out the data to each block in transfer sizes, until the remainder left is 0.
 */
void
WriteOrRead(IOR_param_t * test,
            void        * fd,
            int           access)
{
    int            errors,
                   allErrors;
    IOR_offset_t   amtXferred,
                   blockSize,
                   remainder,
                   segmentCount,
                   totalSegments,
                   transfer,
                   transferCount;
    int            pretendRank;
    void         * buffer;
    void         * checkBuffer;

    pretendRank = (rank + rankOffset) % test->numTasks;
    /* create buffer of filled data */
    buffer = CreateBuffer(test->transferSize);
    FillBuffer(buffer, test->transferSize, 0, pretendRank);
    if (access == WRITECHECK || access == READCHECK) {
        /* on reordered tasks, buffer will contain the wrong rank */
        if (test->reorderTasks)
            FillBuffer(buffer, test->transferSize, 0, pretendRank);
	/* this allocates buffer only */
        checkBuffer = CreateBuffer(test->transferSize);
	FillBuffer(checkBuffer, test->transferSize, 0, pretendRank);
    }
    transfer = test->transferSize;
    if (test->useStridedDatatype) {
        transfer *= test->segmentCount;
    }
    transferCount = 0; /* determine byte-offset into file for error counting */
    errors = 0;
    remainder = blockSize = test->blockSize;
    if (test->filePerProc) {
        test->offset = 0;
    } else {
        test->offset = pretendRank * blockSize;
    }
    segmentCount = test->segmentCount;
    totalSegments = segmentCount;
    /* loop through segments */
    while (segmentCount--) {
        /* keep accessing file until no remainder */
        while (remainder) {
            if (remainder < transfer) {
                transfer = remainder;
            }
            /*
             * The access method of WRITE, READ, WRITECHECK, and READCHECK
             * allow the one function to handle several situations.
             */
            if (access == WRITE) {
                amtXferred = IOR_Xfer(access, fd, buffer, transfer, test);
                if (amtXferred != transfer) ERR("cannot write to file");
            } else if (access == READ) {
                amtXferred = IOR_Xfer(access, fd, buffer, transfer, test);
                if (amtXferred != transfer) ERR("cannot read from file");
            } else if (access == WRITECHECK) {
                memset(checkBuffer, 'a', transfer);
                amtXferred = IOR_Xfer(access, fd, checkBuffer, transfer, test);
                if (amtXferred != transfer)
                    ERR("cannot read from file write check");
                transferCount++;
                errors += CompareBuffers(buffer, checkBuffer, transfer,
                                         transferCount, test, "write");
            } else if (access == READCHECK){
		memset(buffer, 'a', transfer);
		amtXferred = IOR_Xfer(access, fd, buffer, transfer, test);
		if (amtXferred != transfer)
		    ERR("cannot read from file on read check");
                memset(checkBuffer, 'a', transfer);      /* empty buffer */
                amtXferred = IOR_Xfer(access, fd, checkBuffer, transfer, test);
                if (amtXferred != transfer)
                    ERR("cannot reread from file read check");
                transferCount++;
                errors += CompareBuffers(buffer, checkBuffer, transfer,
                                         transferCount, test, "read");
	    }
            test->offset += amtXferred;
            remainder -= amtXferred;

            /*
             * fills each transfer with a unique pattern
             * containing the offset into the file
             */
            if (test->storeFileOffset) FillBuffer(buffer, test->transferSize,
                                                  test->offset, pretendRank);

        }
        transfer = test->transferSize;
        remainder = blockSize;
        if (test->filePerProc) {
            test->offset = (totalSegments - segmentCount)
                                           * blockSize;
        } else {
            test->offset = ((totalSegments - segmentCount) * (blockSize * test->numTasks))
		            + (pretendRank * blockSize);
        }
        if (test->useStridedDatatype) {
            segmentCount = 0;
        }
    }

    if (test->checkWrite || test->checkRead) {
        MPI_CHECK(MPI_Reduce(&errors, &allErrors, 1, MPI_INT, MPI_SUM,
                             0, testComm), "cannot reduce errors");
        if (rank == 0 && allErrors != 0) {
            if (allErrors < 0) {
                fprintf(stdout, "WARNING: overflow in errors counted.\n");
                allErrors = -1;
            }
            if (access == WRITECHECK) {
                fprintf(stdout, "WARNING: incorrect data on write.\n");
                fprintf(stdout, "%d errors found on write check.\n", allErrors);
            } else {
                fprintf(stdout, "WARNING: incorrect data on read.\n");
                fprintf(stdout, "%d errors found on read check.\n", allErrors);
            }
        }
    }
    if (access == WRITECHECK || access == READCHECK) {
        FreeBuffer(checkBuffer);
    }
    FreeBuffer(buffer);

    if (access == WRITE && test->fsync == TRUE) {
        IOR_Fsync(fd);
    }
} /* WriteOrRead() */


/******************************************************************************/
/*
 * Write times taken during each iteration of the test.
 */
     
void
WriteTimes(IOR_param_t  * test,
           double      ** timer,
           int            iteration,
           int            writeOrRead)
{
    char accessType[MAX_STR],
         timerName[MAX_STR];
    int  i,
         start,
         stop;

    if (writeOrRead == WRITE) {
        start = 0;
        stop = 6;
        strcpy(accessType, "WRITE");
    } else if (writeOrRead == READ) {
        start = 6;
        stop = 12;
        strcpy(accessType, "READ");
    } else {
        ERR("incorrect WRITE/READ option");
    }

    for (i = start; i < stop; i++) {
        switch(i) {
	case 0: strcpy(timerName, "write open start"); break;
	case 1: strcpy(timerName, "write open stop"); break;
	case 2: strcpy(timerName, "write start"); break;
	case 3: strcpy(timerName, "write stop"); break;
	case 4: strcpy(timerName, "write close start"); break;
	case 5: strcpy(timerName, "write close stop"); break;
	case 6: strcpy(timerName, "read open start"); break;
	case 7: strcpy(timerName, "read open stop"); break;
	case 8: strcpy(timerName, "read start"); break;
	case 9: strcpy(timerName, "read stop"); break;
	case 10: strcpy(timerName, "read close start"); break;
	case 11: strcpy(timerName, "read close stop"); break;
	default: strcpy(timerName, "invalid timer"); break;
        }
        fprintf(stdout, "Test %d: Iter=%d, Task=%d, Time=%f, %s\n",
		test->id, iteration, (int)rank, timer[i][iteration], timerName);
    }
} /* WriteTimes() */
