/******************************************************************************\
*                                                                              *
*        Copyright (c) 2003, The Regents of the University of California       *
*      See the file COPYRIGHT for a complete copyright notice and license.     *
*                                                                              *
********************************************************************************
*
* CVS info:
*   $RCSfile: iordef.h,v $
*   $Revision: 1.78 $
*   $Date: 2005/06/28 00:16:14 $
*   $Author: loewe $
*
* Purpose:
*       This is a header file that contains the definitions and macros 
*       needed for IOR.
*
\******************************************************************************/

#ifndef _IORDEF_H
#define _IORDEF_H
#include <mpi.h>
#include <stdio.h>
#include <errno.h>

/************************** D E C L A R A T I O N S ***************************/

extern int      numTasks,                          /* MPI variables */
                rank,
                rankOffset,
                verbose;                           /* verbose output */


/*************************** D E F I N I T I O N S ****************************/

#define IOR_RELEASE "IOR-2.8.6"

#ifndef FALSE
#   define FALSE 0
#endif /* not FALSE */

#ifndef TRUE
#   define TRUE 1
#endif /* not TRUE */

#ifndef NULL
#   define NULL ((void *)0)
#endif /* not NULL */

#define KILOBYTE          1000
#define MEGABYTE          1000000
#define GIGABYTE          1000000000

#define KIBIBYTE          (1 << 10)
#define MEBIBYTE          (1 << 20)
#define GIBIBYTE          (1 << 30)

/* for displaying MiB or MB */
#define BASE_TWO          0
#define BASE_TEN          1

/* any write/read access in code */
#define WRITE             0
#define WRITECHECK        1
#define READ              2
#define READCHECK         3
#define CHECK             4

/* verbosity settings */
#define NO_VERBOSE        0
#define LOW_VERBOSE       1
#define MED_VERBOSE       2
#define HIGH_VERBOSE      3
#define ALL_VERBOSE       4

/* for fill bits of signature */
#define LOWER_BITS 44                         /* max storable offset in file */

/* no fill option not available until hdf5-1.6.x */
#define HAVE_HDF5_NO_FILL (H5_VERS_MAJOR > 0 && H5_VERS_MINOR > 5)

#define MAX_STR           1024                /* max string length */  
#define MAX_HINTS         16                  /* max number of hints */  
#define MAX_RETRY         10000               /* max retries for POSIX xfer */

#define DELIMITERS        " \t\r\n="          /* ReadScript() */

/* MACROs for debugging */
#define CORRUPT_FILE      FALSE	              /* intentionally corrupt file
						 for WRITE error-checking */
#define HERE              fprintf(stdout, "** LINE %d (TASK=%d) **\n", \
                                  __LINE__, rank);

typedef long long int     IOR_offset_t;
typedef long long int     IOR_size_t;


/******************************** M A C R O S *********************************/

/******************************************************************************/
/*
 * ERR will display a custom error message as well as an error string from
 * sys_errlist and then exit the program
 */

#define ERR(MSG) do {                                                    \
        fprintf(stdout, "** error **\n");                                \
        fprintf(stdout, "ERROR in %s (line %d): %s.\n",                  \
                __FILE__, __LINE__, MSG);                                \
        fprintf(stdout, "ERROR: %s\n", strerror(errno));                 \
        fprintf(stdout, "** exiting **\n");                              \
        fflush(stdout);                                                  \
        MPI_Abort(MPI_COMM_WORLD, 1);                                    \
} while (0)


/******************************************************************************/
/*
 * MPI_CHECK will display a custom error message as well as an error string
 * from the MPI_STATUS and then exit the program
 */

#define MPI_CHECK(MPI_STATUS, MSG) do {                                  \
    char resultString[MPI_MAX_ERROR_STRING];                             \
    int resultLength;                                                    \
                                                                         \
    if (MPI_STATUS != MPI_SUCCESS) {                                     \
        fprintf(stdout, "** error **\n");                                \
        fprintf(stdout, "ERROR in %s (line %d): %s.\n",                  \
                __FILE__, __LINE__, MSG);                                \
        MPI_Error_string(MPI_STATUS, resultString, &resultLength);       \
        fprintf(stdout, "MPI %s\n", resultString);                       \
        fprintf(stdout, "** exiting **\n");                              \
        fflush(stdout);                                                  \
        MPI_Abort(MPI_COMM_WORLD, 1);                                    \
    }                                                                    \
} while(0)

#endif /* not _IORDEF_H */
